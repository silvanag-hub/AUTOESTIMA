const CACHE = 'autoestima-v2';

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(cache =>
      cache.addAll([
        '/AUTOESTIMA/index.html',
        '/AUTOESTIMA/manifest.json',
        '/AUTOESTIMA/icon-192.png',
        '/AUTOESTIMA/icon-512.png'
      ]).catch(() =>
        // fallback si algún path falla
        cache.add('/AUTOESTIMA/index.html')
      )
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  // Solo cachear requests GET del mismo origen o fuentes confiables
  if (e.request.method !== 'GET') return;

  e.respondWith(
    caches.match(e.request).then(cached => {
      const fetchPromise = fetch(e.request).then(response => {
        if (response && response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE).then(cache => cache.put(e.request, clone));
        }
        return response;
      }).catch(() => null);

      // Devuelve cache si existe, sino red
      return cached || fetchPromise || caches.match('/AUTOESTIMA/index.html');
    })
  );
});
